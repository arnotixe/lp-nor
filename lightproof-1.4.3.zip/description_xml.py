# -*- encoding: UTF-8 -*-
"""<?xml version="1.0" encoding="UTF-8"?>
<description xmlns="http://openoffice.org/extensions/description/2006"
        xmlns:d="http://openoffice.org/extensions/description/2006"
        xmlns:xlink="http://www.w3.org/1999/xlink">
        <identifier value="org.openoffice.comp.pyuno.lightproof.oxt.%s" />
        <display-name>
                <name lang="en-US">%s</name>
        </display-name>
        <version value="%s" />
        <publisher>
        <name lang="en" xlink:href="%s">%s</name>
    </publisher>        
        <dependencies>
                <OpenOffice.org-minimal-version value="3.0.1"
                        d:name="OpenOffice.org 3.0.1" />
        </dependencies>
</description>
"""
